// State Management
let all_data = [];
let filtered_data = [];
let currentPage = 1;
let pageSize = 9;
let currentView = 'list-view';

// Filter State
const state = {
  search: '',
  platform: 'all',
  genre: 'all'
};

// Fetch Data
function fetchData() {
  renderSkeletons();
  const xhr = new XMLHttpRequest();
  xhr.withCredentials = true;
  xhr.open("GET", "https://free-to-play-games-database.p.rapidapi.com/api/games");
  xhr.setRequestHeader("X-RapidAPI-Key", "431e2e0512msh12ec0cf6343c1c8p1de776jsnb12502d1e36b");
  xhr.setRequestHeader("X-RapidAPI-Host", "free-to-play-games-database.p.rapidapi.com");

  xhr.addEventListener("readystatechange", function () {
    if (this.readyState === this.DONE) {
      all_data = JSON.parse(this.responseText);
      filtered_data = [...all_data];
      populateGenres();
      renderApp();
    }
  });
  xhr.send(null);
}

// Initial Call
fetchData();

// UI Event Listeners
document.getElementById('listViewBtn').addEventListener('click', () => setView('list-view'));
document.getElementById('gridViewBtn').addEventListener('click', () => setView('grid-view'));
document.getElementById('pageSize').addEventListener('change', (e) => {
  pageSize = parseInt(e.target.value);
  currentPage = 1;
  renderApp();
});

// Search & Filter Listeners
document.getElementById('searchInput').addEventListener('input', (e) => {
  state.search = e.target.value.toLowerCase();
  applyFilters();
});

document.getElementById('platformFilter').addEventListener('change', (e) => {
  state.platform = e.target.value;
  applyFilters();
});

document.getElementById('genreFilter').addEventListener('change', (e) => {
  state.genre = e.target.value;
  applyFilters();
});

// Modal Logic
const modal = document.getElementById("devModal");
const openBtn = document.getElementById("openModal");
const closeBtn = document.getElementsByClassName("close-modal")[0];

openBtn.onclick = () => modal.style.display = "block";
closeBtn.onclick = () => modal.style.display = "none";
window.onclick = (event) => {
  if (event.target == modal) modal.style.display = "none";
}

function setView(view) {
  currentView = view;
  document.getElementById('listViewBtn').classList.toggle('active', view === 'list-view');
  document.getElementById('gridViewBtn').classList.toggle('active', view === 'grid-view');
  renderApp();
}

function populateGenres() {
  const genres = [...new Set(all_data.map(game => game.genre))].sort();
  const select = document.getElementById('genreFilter');
  genres.forEach(genre => {
    const option = document.createElement('option');
    option.value = genre;
    option.textContent = genre;
    select.appendChild(option);
  });
}

function applyFilters() {
  filtered_data = all_data.filter(game => {
    const matchesSearch = game.title.toLowerCase().includes(state.search) ||
      game.short_description.toLowerCase().includes(state.search);
    const matchesPlatform = state.platform === 'all' ||
      (state.platform === 'pc' && game.platform.toLowerCase().includes('pc')) ||
      (state.platform === 'browser' && game.platform.toLowerCase().includes('web browser'));
    const matchesGenre = state.genre === 'all' || game.genre === state.genre;

    return matchesSearch && matchesPlatform && matchesGenre;
  });

  currentPage = 1;
  renderApp();
}

function renderSkeletons() {
  const gamesContainer = document.getElementById("free_games");
  let html = ``;
  for (let i = 0; i < 6; i++) {
    html += `
      <div class="item skeleton-container">
        <div class="img-container skeleton skeleton-img"></div>
        <div class="info">
          <div class="skeleton skeleton-title"></div>
          <div class="skeleton skeleton-text"></div>
          <div class="skeleton skeleton-text" style="width: 40%"></div>
        </div>
      </div>
    `;
  }
  gamesContainer.innerHTML = html;
}

function renderApp() {
  const gamesContainer = document.getElementById("free_games");
  gamesContainer.className = `games-container ${currentView}`;

  const startIndex = (currentPage - 1) * pageSize;
  const endIndex = startIndex + pageSize;
  const currentGames = filtered_data.slice(startIndex, endIndex);

  if (currentGames.length === 0) {
    gamesContainer.innerHTML = `<div class="no-results" style="padding: 40px; text-align: center; color: var(--text-secondary);">No games found matching your criteria.</div>`;
    document.getElementById("pagination").innerHTML = '';
    return;
  }

  let html = ``;
  currentGames.forEach(game => {
    html += `
      <div class="item">
        <div class="img-container">
          <a href="${game.freetogame_profile_url}" target="_blank">
            <img src="${game.thumbnail}" alt="${game.title}" loading="lazy">
          </a>
        </div>
        <div class="info">
          <div class="info-header">
            <h2>${game.title}</h2>
            <span class="genre">${game.genre}</span>
          </div>
          <div class="meta-info">
            <span>${game.platform}</span> • <span>${game.developer}</span>
          </div>
          <p class="description">${game.short_description}</p>
          <span class="release-date">Release Date: <b>${game.release_date}</b></span>
        </div>
        <div class="action">
          <a class="btn" href="${game.game_url}" target="_blank">Get It</a>
        </div>
      </div>
    `;
  });

  gamesContainer.innerHTML = html;
  renderPagination();
}

function renderPagination() {
  const paginationContainer = document.getElementById("pagination");
  const totalPages = Math.ceil(filtered_data.length / pageSize);

  if (totalPages <= 1) {
    paginationContainer.innerHTML = '';
    return;
  }

  let html = `<button class="page-btn" ${currentPage === 1 ? 'disabled' : ''} onclick="changePage(${currentPage - 1})">Prev</button>`;

  for (let i = 1; i <= totalPages; i++) {
    if (i === 1 || i === totalPages || (i >= currentPage - 2 && i <= currentPage + 2)) {
      html += `<button class="page-btn ${i === currentPage ? 'active' : ''}" onclick="changePage(${i})">${i}</button>`;
    } else if (i === currentPage === 3 || i === currentPage + 3) {
      if (!html.endsWith('...</span>')) html += `<span style="color: grey">...</span>`;
    }
  }

  html += `<button class="page-btn" ${currentPage === totalPages ? 'disabled' : ''} onclick="changePage(${currentPage + 1})">Next</button>`;

  paginationContainer.innerHTML = html;
}

window.changePage = (page) => {
  currentPage = page;
  renderApp();
  window.scrollTo({ top: 300, behavior: 'smooth' });
}